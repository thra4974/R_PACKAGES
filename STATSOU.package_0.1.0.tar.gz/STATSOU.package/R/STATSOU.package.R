#' STATS OU Package
#'
#' Contains function for computing the total sum of squares
#'
#' @docType package
#'
#' @author Tristan Thrasher \email{tristan.thrasher-1@ou.edu}
#'
#' @name STATSOU.package
NULL
